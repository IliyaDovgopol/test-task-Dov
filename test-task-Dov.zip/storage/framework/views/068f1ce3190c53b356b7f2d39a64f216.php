<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>

    <!-- Condition to display the top navigation bar only if not on the login or register page -->
    <?php if(!request()->is('login') && !request()->is('register')): ?>
        <!-- Top navigation bar -->
        <nav class="navbar">
            <div class="container">
                <a href="<?php echo e(url('/home')); ?>" class="navbar-brand">Home</a>

                <!-- User panel -->
                <div class="navbar-user">
                    <?php if(auth()->check()): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link">Logout</button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn">Login</a>
                        <a href="<?php echo e(route('register')); ?>" class="btn">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>
<?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/layouts/app.blade.php ENDPATH**/ ?>