<!-- resources/views/home.blade.php -->



<?php $__env->startSection('title', 'User Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-container">
    <h1 class="dashboard-title">User Dashboard</h1>
    <p class="dashboard-welcome">Welcome, <?php echo e(auth()->user()->name); ?>!</p>

	<div class="user-details">
        <p>Name: <strong><?php echo e(auth()->user()->name); ?></strong></p>
        <p>Email: <strong><?php echo e(auth()->user()->email); ?></strong></p>
    </div>

    <!-- Available actions -->
    <h2 class="section-title">Available actions</h2>
    <ul class="dashboard-actions">
        <li><a href="<?php echo e(route('pageA')); ?>">Page A</a></li>
        <li><a href="<?php echo e(route('pageB')); ?>">Page B</a></li>

    <!-- Administrative actions -->
    <?php if(auth()->user()->role === 'admin'): ?>
            <li><a href="<?php echo e(route('statistics')); ?>">Statistics</a></li>
            <li><a href="<?php echo e(route('reports')); ?>">Reports</a></li>
        </ul>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/home.blade.php ENDPATH**/ ?>