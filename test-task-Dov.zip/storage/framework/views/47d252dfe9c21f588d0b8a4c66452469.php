<!-- resources/views/auth/register.blade.php -->



<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>

<div class="login-container">
    <h1>Register</h1>

    <form action="<?php echo e(route('register')); ?>" method="post" class="login-form">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div>
            <label for="password_confirmation">Confirm Password:</label>
            <input type="password" id="password_confirmation" name="password_confirmation" required>
        </div>
        <button type="submit">Register</button>
    </form>

    <!-- Link to login page -->
    <p class="register-prompt">
        Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a>
    </p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/auth/register.blade.php ENDPATH**/ ?>