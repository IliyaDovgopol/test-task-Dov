<!-- resources/views/admin/statistics.blade.php -->



<?php $__env->startSection('title', 'User Activity Statistics'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>User Activity Statistics</h1>

    <!-- Filter form -->
    <form method="GET" action="<?php echo e(route('statistics')); ?>">
        <div class="form-group">
            <label for="start_date">Start Date</label>
            <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
        </div>

        <div class="form-group">
            <label for="end_date">End Date</label>
            <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
        </div>

        <div class="form-group">
            <label for="user_id">User</label>
            <select id="user_id" name="user_id" class="form-control">
                <option value="">All users</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="action">Action</label>
            <select id="action" name="action" class="form-control">
                <option value="">All actions</option>
                <option value="login" <?php echo e(request('action') == 'login' ? 'selected' : ''); ?>>Login</option>
                <option value="logout" <?php echo e(request('action') == 'logout' ? 'selected' : ''); ?>>Logout</option>
                <option value="registration" <?php echo e(request('action') == 'registration' ? 'selected' : ''); ?>>Registration</option>
                <option value="buy_cow" <?php echo e(request('action') == 'buy_cow' ? 'selected' : ''); ?>>Buy a Cow</option>
                <option value="download" <?php echo e(request('action') == 'download' ? 'selected' : ''); ?>>Download</option>
                <option value="page-a" <?php echo e(request('action') == 'page-a' ? 'selected' : ''); ?>>View Page A</option>
                <option value="page-b" <?php echo e(request('action') == 'page-b' ? 'selected' : ''); ?>>View Page B</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Filter</button>
    </form>

    <!-- Results table -->
    <table class="table mt-4">
        <thead>
            <tr>
                <th>Date</th>
                <th>User</th>
                <th>Action</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($activity->created_at); ?></td>
                    <td><?php echo e($activity->user->name); ?></td>
                    <td><?php echo e($activity->action); ?></td>
                    <td><?php echo e($activity->description); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/admin/statistics.blade.php ENDPATH**/ ?>