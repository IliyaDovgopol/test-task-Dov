<!-- resources/views/page-b.blade.php -->



<?php $__env->startSection('title', 'Page B - Download File'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Page B</h1>

    <!-- Direct link to download the file -->
    <a href="<?php echo e(asset('downloads/download.exe')); ?>" id="download-button" class="btn btn-primary" download>Download File</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/page-b.blade.php ENDPATH**/ ?>