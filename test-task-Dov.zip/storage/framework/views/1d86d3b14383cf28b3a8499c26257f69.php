<!-- resources/views/auth/login.blade.php -->



<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<div class="login-container">
    <h1>Login</h1>

    <form action="<?php echo e(route('login')); ?>" method="post" class="login-form">
        <?php echo csrf_field(); ?>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Login</button>
    </form>

    <!-- Link to registration -->
    <p class="register-prompt">
        Don't have an account? <a href="<?php echo e(route('register')); ?>">Register</a>
    </p>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\имя_проекта\resources\views/auth/login.blade.php ENDPATH**/ ?>